const header = document.querySelector("header");
    let scrollAmount = null;
    window.addEventListener("scroll",function(){
      scrollAmount = window.scrollY;
      if (scrollAmount > 50) {
        header.classList.add("scrollview");
      }else{
        header.classList.remove("scrollview");
      }
    });

    let mobileMenu = document.querySelector(".dino-mobile-menu");
    document.getElementById("showProductsIcon").addEventListener("click",function(event){
      console.log("asdasdasdasdsad");
    event.target.classList.toggle("closeIcon");
    mobileMenu.classList.toggle("show");
    });